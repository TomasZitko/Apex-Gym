"use client"

import { useState } from "react"
import Link from "next/link"
import { Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function MobileMenu() {
  const [open, setOpen] = useState(false)

  const handleLinkClick = () => {
    setOpen(false)
  }

  return (
    <Sheet open={open} onOpenChange={setOpen}>
      <SheetTrigger asChild>
        <Button variant="outline" size="icon" className="md:hidden border-zinc-800">
          <Menu className="h-6 w-6" />
          <span className="sr-only">Open menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="right" className="bg-black border-zinc-800 p-0">
        <SheetHeader className="p-6 border-b border-zinc-800">
          <SheetTitle className="text-left text-2xl font-bold tracking-tighter bg-gradient-to-r from-zinc-100 to-zinc-400 bg-clip-text text-transparent">
            APEX GYM
          </SheetTitle>
        </SheetHeader>
        <nav className="flex flex-col p-6">
          <Link
            href="#features"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors border-b border-zinc-800"
            onClick={handleLinkClick}
          >
            Features
          </Link>
          <Link
            href="#classes"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors border-b border-zinc-800"
            onClick={handleLinkClick}
          >
            Classes
          </Link>
          <Link
            href="#team"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors border-b border-zinc-800"
            onClick={handleLinkClick}
          >
            Team
          </Link>
          <Link
            href="#testimonials"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors border-b border-zinc-800"
            onClick={handleLinkClick}
          >
            Testimonials
          </Link>
          <Link
            href="#pricing"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors border-b border-zinc-800"
            onClick={handleLinkClick}
          >
            Pricing
          </Link>
          <Link
            href="#contact"
            className="py-4 text-lg font-medium text-zinc-400 hover:text-white transition-colors"
            onClick={handleLinkClick}
          >
            Contact
          </Link>

          <Button className="mt-8 bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
            Join Now
          </Button>
        </nav>
      </SheetContent>
    </Sheet>
  )
}
