import Image from "next/image"
import Link from "next/link"
import { Dumbbell, MapPin, Phone, Mail, Instagram, Facebook, Twitter } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import FeatureCarousel from "@/components/feature-carousel"
import MobileMenu from "@/components/mobile-menu"

export default function Home() {
  // Feature images for carousels
  const gymImages = [
    "/placeholder.svg?height=500&width=500&text=Gym+1",
    "/placeholder.svg?height=500&width=500&text=Gym+2",
    "/placeholder.svg?height=500&width=500&text=Gym+3",
    "/placeholder.svg?height=500&width=500&text=Gym+4",
  ]

  const wellnessImages = [
    "/placeholder.svg?height=500&width=500&text=Wellness+1",
    "/placeholder.svg?height=500&width=500&text=Wellness+2",
    "/placeholder.svg?height=500&width=500&text=Wellness+3",
    "/placeholder.svg?height=500&width=500&text=Wellness+4",
  ]

  const smoothieImages = [
    "/placeholder.svg?height=500&width=500&text=Smoothie+1",
    "/placeholder.svg?height=500&width=500&text=Smoothie+2",
    "/placeholder.svg?height=500&width=500&text=Smoothie+3",
    "/placeholder.svg?height=500&width=500&text=Smoothie+4",
  ]

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <header className="fixed w-full z-50 bg-black/80 backdrop-blur-md border-b border-zinc-800">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <Link href="/" className="flex items-center space-x-2">
              <span className="text-2xl font-bold tracking-tighter bg-gradient-to-r from-zinc-100 to-zinc-400 bg-clip-text text-transparent">
                APEX GYM
              </span>
            </Link>
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="#features" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Features
              </Link>
              <Link href="#classes" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Classes
              </Link>
              <Link href="#team" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Team
              </Link>
              <Link
                href="#testimonials"
                className="text-sm font-medium text-zinc-400 hover:text-white transition-colors"
              >
                Testimonials
              </Link>
              <Link href="#pricing" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Pricing
              </Link>
              <Link href="#contact" className="text-sm font-medium text-zinc-400 hover:text-white transition-colors">
                Contact
              </Link>
            </nav>
            <div className="flex items-center space-x-4">
              <Button className="hidden md:flex bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
                Join Now
              </Button>
              <MobileMenu />
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative h-screen flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <Image
            src="/placeholder.svg?height=1080&width=1920"
            alt="Gym Interior"
            fill
            className="object-cover opacity-50"
            priority
          />
          <div className="absolute inset-0 bg-gradient-to-t from-black via-black/70 to-black/30" />
        </div>

        <div className="container mx-auto px-4 z-10 text-center">
          <h1 className="text-5xl md:text-7xl font-bold tracking-tighter mb-6 bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">
            TRAIN. RECOVER. REPEAT.
          </h1>
          <p className="text-xl md:text-2xl text-zinc-400 max-w-2xl mx-auto mb-8">
            Experience the future of fitness at our state-of-the-art facility
          </p>
          <Button className="bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 text-white px-8 py-6 text-lg rounded-md border border-zinc-700">
            Explore the Gym
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-24 bg-zinc-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            Our <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Premium</span>{" "}
            Facilities
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Gym Feature */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <FeatureCarousel images={gymImages} />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <Dumbbell className="mr-2 h-5 w-5 text-zinc-400" /> Gym
                </h3>
                <ul className="space-y-2 text-zinc-400">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>300 m² of open space</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Cardio machines (treadmills, bikes, rowing)</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Boxing bag + functional zone</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Wellness Feature */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <FeatureCarousel images={wellnessImages} />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-2 text-zinc-400"
                  >
                    <path d="M14.5 2v16.5c0 1.4-1.1 2.5-2.5 2.5h0c-1.4 0-2.5-1.1-2.5-2.5V2" />
                    <path d="M8.5 2h7" />
                    <path d="M14.5 16h-5" />
                  </svg>{" "}
                  Wellness & Sauna
                </h3>
                <ul className="space-y-2 text-zinc-400">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Finnish sauna</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Relax & recovery zone</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Towel service</span>
                  </li>
                </ul>
              </div>
            </div>

            {/* Smoothie Bar Feature */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <FeatureCarousel images={smoothieImages} />
              <div className="p-6">
                <h3 className="text-xl font-bold mb-4 flex items-center">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="20"
                    height="20"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="mr-2 text-zinc-400"
                  >
                    <path d="M6 9h12v13H6z" />
                    <path d="M5 5a4 4 0 0 1 4-4h6a4 4 0 0 1 4 4v4H5V5z" />
                    <path d="M5 9v13" />
                    <path d="M19 9v13" />
                  </svg>{" "}
                  Smoothie Bar
                </h3>
                <ul className="space-y-2 text-zinc-400">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Protein-rich smoothies</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Fresh juices & snacks</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Chill-out area with Wi-Fi</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Classes Section */}
      <section id="classes" className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            Our <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Classes</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Calisthenics Class */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-video relative">
                <Image
                  src="/placeholder.svg?height=400&width=600&text=Calisthenics"
                  alt="Calisthenics Class"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <span className="bg-zinc-800 text-white text-xs px-2 py-1 rounded">Mon, Wed, Fri</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Calisthenics</h3>
                <p className="text-zinc-400 text-sm mb-4">
                  Master your bodyweight with our expert-led calisthenics classes. Build strength, flexibility, and
                  control through progressive movements.
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                      <Image
                        src="/placeholder.svg?height=100&width=100&text=MJ"
                        alt="Instructor"
                        width={32}
                        height={32}
                        className="object-cover"
                      />
                    </div>
                    <span className="text-zinc-300 text-sm">Mike Johnson</span>
                  </div>
                  <span className="text-zinc-400 text-sm">18:00 - 19:30</span>
                </div>
              </div>
            </div>

            {/* Pilates Class */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-video relative">
                <Image
                  src="/placeholder.svg?height=400&width=600&text=Pilates"
                  alt="Pilates Class"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <span className="bg-zinc-800 text-white text-xs px-2 py-1 rounded">Tue, Thu</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Pilates</h3>
                <p className="text-zinc-400 text-sm mb-4">
                  Strengthen your core and improve posture with our Pilates classes. Perfect for all fitness levels with
                  modifications available.
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                      <Image
                        src="/placeholder.svg?height=100&width=100&text=SL"
                        alt="Instructor"
                        width={32}
                        height={32}
                        className="object-cover"
                      />
                    </div>
                    <span className="text-zinc-300 text-sm">Sarah Lee</span>
                  </div>
                  <span className="text-zinc-400 text-sm">17:00 - 18:00</span>
                </div>
              </div>
            </div>

            {/* Personal Training */}
            <div className="bg-zinc-900 border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-video relative">
                <Image
                  src="/placeholder.svg?height=400&width=600&text=Personal+Training"
                  alt="Personal Training"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent opacity-70"></div>
                <div className="absolute bottom-0 left-0 p-4">
                  <span className="bg-zinc-800 text-white text-xs px-2 py-1 rounded">By Appointment</span>
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Personal Workouts</h3>
                <p className="text-zinc-400 text-sm mb-4">
                  Customized training sessions tailored to your specific goals. One-on-one attention from our certified
                  trainers.
                </p>
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-8 h-8 rounded-full overflow-hidden mr-2">
                      <Image
                        src="/placeholder.svg?height=100&width=100&text=DT"
                        alt="Instructor"
                        width={32}
                        height={32}
                        className="object-cover"
                      />
                    </div>
                    <span className="text-zinc-300 text-sm">David Thompson</span>
                  </div>
                  <span className="text-zinc-400 text-sm">Flexible Hours</span>
                </div>
              </div>
            </div>
          </div>

          <div className="text-center mt-12">
            <Button className="bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
              View Full Schedule
            </Button>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section id="team" className="py-24 bg-zinc-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            Meet the <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Team</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Team Member 1 */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-[3/4] relative">
                <Image
                  src="/placeholder.svg?height=600&width=450&text=Trainer+1"
                  alt="Trainer 1"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold">John Doe</h3>
                <p className="text-zinc-400 mb-4">Head Fitness Coach</p>
                <p className="text-zinc-500 text-sm">
                  Certified personal trainer with 10+ years of experience in strength training and functional fitness.
                  John specializes in helping clients achieve their strength and conditioning goals.
                </p>
              </div>
            </div>

            {/* Team Member 2 */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-[3/4] relative">
                <Image
                  src="/placeholder.svg?height=600&width=450&text=Trainer+2"
                  alt="Trainer 2"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold">Emma Wilson</h3>
                <p className="text-zinc-400 mb-4">Nutrition Specialist</p>
                <p className="text-zinc-500 text-sm">
                  Registered dietitian with expertise in sports nutrition. Emma helps members optimize their diet to
                  complement their fitness routines and achieve their body composition goals.
                </p>
              </div>
            </div>

            {/* Team Member 3 */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300 group">
              <div className="aspect-[3/4] relative">
                <Image
                  src="/placeholder.svg?height=600&width=450&text=Trainer+3"
                  alt="Trainer 3"
                  fill
                  className="object-cover transition-transform duration-500 group-hover:scale-105"
                />
              </div>
              <div className="p-6">
                <h3 className="text-xl font-bold">Michael Chen</h3>
                <p className="text-zinc-400 mb-4">Recovery Specialist</p>
                <p className="text-zinc-500 text-sm">
                  Certified in physical therapy and sports medicine. Michael focuses on injury prevention, mobility
                  work, and recovery techniques to keep members performing at their best.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials Section */}
      <section id="testimonials" className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            What Our{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Members</span> Say
          </h2>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {/* Testimonial 1 */}
            <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100&text=1"
                      alt="Member"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Sarah Johnson</h4>
                    <p className="text-zinc-400 text-sm">Member since 2022</p>
                  </div>
                </div>
                <p className="text-zinc-400">
                  "The facilities are top-notch and the trainers are incredibly knowledgeable. I've seen amazing results
                  since joining this gym! The sauna is my favorite place to recover after an intense workout."
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 2 */}
            <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100&text=2"
                      alt="Member"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Mark Rodriguez</h4>
                    <p className="text-zinc-400 text-sm">Member since 2021</p>
                  </div>
                </div>
                <p className="text-zinc-400">
                  "I've been to many gyms, but this one stands out. The equipment is always clean and well-maintained,
                  and the staff goes above and beyond to help. The smoothie bar is a great bonus after workouts!"
                </p>
              </CardContent>
            </Card>

            {/* Testimonial 3 */}
            <Card className="bg-zinc-900 border-zinc-800 hover:border-zinc-700 transition-all duration-300">
              <CardContent className="p-6">
                <div className="flex items-center mb-4">
                  <div className="w-12 h-12 rounded-full overflow-hidden mr-4">
                    <Image
                      src="/placeholder.svg?height=100&width=100&text=3"
                      alt="Member"
                      width={48}
                      height={48}
                      className="object-cover"
                    />
                  </div>
                  <div>
                    <h4 className="font-bold">Jennifer Lee</h4>
                    <p className="text-zinc-400 text-sm">Member since 2023</p>
                  </div>
                </div>
                <p className="text-zinc-400">
                  "The calisthenics classes have transformed my fitness journey. I've gained strength I never thought
                  possible, and the community here is so supportive. Definitely worth every penny!"
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Pricing Section */}
      <section id="pricing" className="py-24 bg-zinc-900">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            Membership{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Pricing</span>
          </h2>

          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {/* Monthly Pass */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Monthly Pass</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">$79</span>
                  <span className="text-zinc-400">/month</span>
                </div>
                <ul className="space-y-2 text-zinc-400 mb-6">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Unlimited gym access</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>2 sauna sessions/week</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>10% off smoothie bar</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Access to all classes</span>
                  </li>
                </ul>
                <Button className="w-full bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
                  Choose Plan
                </Button>
              </div>
            </div>

            {/* One-Time Entry */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">One-Time Entry</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">$15</span>
                  <span className="text-zinc-400">/visit</span>
                </div>
                <ul className="space-y-2 text-zinc-400 mb-6">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Full day gym access</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>1 sauna session</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Locker included</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Access to day's classes</span>
                  </li>
                </ul>
                <Button className="w-full bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
                  Choose Plan
                </Button>
              </div>
            </div>

            {/* Student Discount */}
            <div className="bg-black border border-zinc-800 rounded-lg overflow-hidden hover:border-zinc-700 transition-all duration-300">
              <div className="p-6">
                <h3 className="text-xl font-bold mb-2">Student Discount</h3>
                <div className="mb-4">
                  <span className="text-3xl font-bold">$59</span>
                  <span className="text-zinc-400">/month</span>
                </div>
                <ul className="space-y-2 text-zinc-400 mb-6">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Unlimited gym access</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>1 sauna session/week</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>5% off smoothie bar</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Valid student ID required</span>
                  </li>
                </ul>
                <Button className="w-full bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
                  Choose Plan
                </Button>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Location & Contact */}
      <section id="contact" className="py-24 bg-black">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-16 tracking-tight">
            Location &{" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-white to-zinc-400">Contact</span>
          </h2>

          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="aspect-video relative rounded-lg overflow-hidden">
              <Image
                src="/placeholder.svg?height=600&width=800&text=Map"
                alt="Map Location"
                fill
                className="object-cover"
              />
            </div>

            <div className="space-y-8">
              <div>
                <h3 className="text-xl font-bold mb-4">Find Us</h3>
                <div className="space-y-4">
                  <div className="flex items-start">
                    <MapPin className="h-5 w-5 text-zinc-400 mr-3 mt-0.5" />
                    <div>
                      <p className="text-zinc-300">123 Fitness Street</p>
                      <p className="text-zinc-400">New York, NY 10001</p>
                    </div>
                  </div>

                  <div className="flex items-start">
                    <Phone className="h-5 w-5 text-zinc-400 mr-3 mt-0.5" />
                    <p className="text-zinc-300">+1 (555) 123-4567</p>
                  </div>

                  <div className="flex items-start">
                    <Mail className="h-5 w-5 text-zinc-400 mr-3 mt-0.5" />
                    <p className="text-zinc-300">info@apexgym.com</p>
                  </div>
                </div>
              </div>

              <div>
                <h3 className="text-xl font-bold mb-4">Opening Hours</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <p className="text-zinc-400">Monday - Friday</p>
                    <p className="text-zinc-300">6:00 AM - 10:00 PM</p>
                  </div>
                  <div className="flex justify-between">
                    <p className="text-zinc-400">Saturday</p>
                    <p className="text-zinc-300">8:00 AM - 8:00 PM</p>
                  </div>
                  <div className="flex justify-between">
                    <p className="text-zinc-400">Sunday</p>
                    <p className="text-zinc-300">8:00 AM - 6:00 PM</p>
                  </div>
                </div>
              </div>

              <Button className="w-full bg-gradient-to-r from-zinc-700 to-zinc-900 hover:from-zinc-600 hover:to-zinc-800 border border-zinc-700">
                Get Directions
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-zinc-900 py-12 border-t border-zinc-800">
        <div className="container mx-auto px-4">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="mb-6 md:mb-0">
              <Link href="/" className="flex items-center space-x-2">
                <span className="text-2xl font-bold tracking-tighter bg-gradient-to-r from-zinc-100 to-zinc-400 bg-clip-text text-transparent">
                  APEX GYM
                </span>
              </Link>
              <p className="text-zinc-500 mt-2 text-sm">Train. Recover. Repeat.</p>
            </div>

            <div className="flex space-x-6 mb-6 md:mb-0">
              <Link href="#" className="text-zinc-400 hover:text-white transition-colors">
                <Instagram className="h-5 w-5" />
                <span className="sr-only">Instagram</span>
              </Link>
              <Link href="#" className="text-zinc-400 hover:text-white transition-colors">
                <Facebook className="h-5 w-5" />
                <span className="sr-only">Facebook</span>
              </Link>
              <Link href="#" className="text-zinc-400 hover:text-white transition-colors">
                <Twitter className="h-5 w-5" />
                <span className="sr-only">Twitter</span>
              </Link>
            </div>
          </div>

          <div className="border-t border-zinc-800 mt-8 pt-8 flex flex-col md:flex-row justify-between items-center">
            <p className="text-zinc-500 text-sm">&copy; {new Date().getFullYear()} APEX GYM. All rights reserved.</p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="#" className="text-zinc-500 hover:text-zinc-300 text-sm transition-colors">
                Privacy Policy
              </Link>
              <Link href="#" className="text-zinc-500 hover:text-zinc-300 text-sm transition-colors">
                Terms of Service
              </Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  )
}
